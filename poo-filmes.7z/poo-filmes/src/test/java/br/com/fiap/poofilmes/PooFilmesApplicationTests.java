package br.com.fiap.poofilmes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooFilmesApplicationTests {

    @Test
    void contextLoads() {
    }

}
