package br.com.fiap.poofilmes.model;

public interface Classificavel {
    int calcularAvaliacao();
}
