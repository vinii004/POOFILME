import {applyTheme as _applyTheme} from './theme-my-theme.generated.js';
export const applyTheme = _applyTheme;
